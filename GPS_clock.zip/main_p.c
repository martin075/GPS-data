/*************************************************************************
Title:    Interprets NMEA messages on the UART
Author:   crasbe  <crasbe@gmail.com>  http://www.crasbe.de/
          Peter Fleury (LCD- and UART-Library)
File:     main.c
Software: AVR-GCC 
Hardware: HD44780 compatible LCD text display
		  GPS module sending NMEA messages over serial
		  i2C pins for LCD, 1 for UART
 $GPGGA,123519,4807.038,N,01131.324,E,1,08,0.9,545.4,M,46.9,M, , *42
		1  ,   2   ,2,    3    ,3,    4,5, 6  ,7,      8  ,9,  10
	01 - 123519 = Acquisition du FIX a 12:35:19 UTC
	02 - 4807.038,N = Latitude 48�07.038' N
	03 - 131.324,E = Longitude 11�31.324' E
	04 - 1 = Fix qualification : (0 = non valide, 1 = Fix GPS, 2 = Fix DGPS)
	05 - 08 = Number os satellites en poursuite.
	06 - 0.9 = DOP (Horizontal dilution of position) Dilution horizontale.
	07 - 545.4,M = Altitude, en Metres, au dessus du MSL (mean see level) niveau moyen des Oc�ans.
	08 - 46.9,M = Correction de la hauteur de la g�oide en Metres par rapport a l'�llipsoide WGS84 (MSL).
	09 - (Champ vide) = nombre de secondes �coul�es depuis la derniere mise a jour DGPS.
	10 - (Champ vide) = Identification de la station DGPS.
	11 - *42 = Checksum
	12 - Non repr�sent�s CR et LF.

**************************************************************************/
#include <avr/io.h>
#include <avr/sleep.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>

#include <util/delay.h>
#include "lcdpcf8574/lcdpcf8574.h"	//i2c addr 3F 
//#include "lcd.h"
#include "uart.h"
#include "gpsclock.h"

#define REVISION "R2 2019"

/*****************************
 * u-blox 7 configuration
 * for Timepulse
 *****************************/

// this configuration changes the timepulse output of the u-blox
// NEO-7M module to 10kHz. be aware that this might not be the
// configuration you desire!
// Please refer to the u-blox receiver description!
	#define UBLOX_CONF
#ifdef UBLOX_CONF
	const unsigned char configuration[40] PROGMEM = { 
	0xB5, 0x62, 0x06, 0x31, 0x20, 0x00, 
	0x00, 0x01, 0x00, 0x00, 0x32, 0x00, 0x00, 0x00,
	0x01, 0x00, 0x00, 0x00, 0x10, 0x27, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80,
	0x00, 0x00, 0x00, 0x00, 0xEF, 0x00, 0x00, 0x00,
	0x31, 0xDB };
#endif

// global variables-----------------


int main(void) {
	
	
	uint8_t led = 0; //display ON
	uint8_t state = NO_CMD; // state of the receiving process
	
	// comma position
	// GPGGA - time after first comma, satellite count after seventh comma
	//       - $GPGGA,hhmmss.00,,,,,,nn,,
	// GPGSA - lock after second comma
	//		 - $GPGSA,,l,,,,
	uint8_t comma = 0;
	unsigned int c; 		// received char from the UART
	unsigned char input;	// the same, converted to char
	char gps_time[10], latitude[14], longitude[14], sat_numb[5], DOP[5], alt[8];
	uint8_t count_j, count_k, latitude_n_s, longitude_w_e;	

	// buffer for receiving command, time, satellite count or lock state
	char buffer[9];
	
	uint8_t bufpos = 0;
	
	// receive the lock state
	uint8_t lock = 1;
	//----------------
	lock = lock;
	bufpos = bufpos;
	buffer[0] = buffer[0];
	input = input;
	state = state;
	comma = comma;

	//-------init LCD 
	lcd_init(LCD_DISP_ON);
    lcd_home();
	lcd_led(led);


	// initialize UART and enable interrupts
	uart_init( UART_BAUD_SELECT(UART_BAUD_RATE,F_CPU) );
	sei();
	
	//lcd_init(LCD_DISP_ON); 		// initialize display, cursor off
	//lcd_clrscr(); 				// clear the LCD
	
	lcd_puts_P("GPS-Clock, "REVISION);
	
	_delay_ms(2000);
	
	// the ublox-module should be booted now..
#ifdef UBLOX_CONF
	for(uint8_t i = 0; i < 40; i++) {
		uart_putc((unsigned char) pgm_read_byte(&(configuration[i])));
	}
#endif	
	
	lcd_clrscr();
	lcd_puts_P(TXT_TEMPLATE);	// write a template to the screen
	
	for (;;) {
		set_sleep_mode(SLEEP_MODE_IDLE);
        sleep_mode();
		c = uart_getc(); // get a char from the buffer
		
		if (c & UART_NO_DATA) { // nothing received
			continue;
		} else if(	c & UART_FRAME_ERROR || c & UART_OVERRUN_ERROR || 
					c & UART_BUFFER_OVERFLOW) {
			uart_puts_P("UART Error!\n");
			continue;
		}
		input = (unsigned char) c; // convert input to unsigned char
		
		for(count_k=0;count_k<=3;count_k++)
			{
			get_GPGGA();
			//1 - time
			lcd_gotoxy(time_x,time_y);
			for(count_j=0;count_j<=1;count_j++)
				{
				lcd_putc(gps_time[count_j]);
				}
			lcd_putc(':');
			for(count_j=2;count_j<=3;count_j++){
				lcd_putc(gps_time[count_j]);
				}
				lcd_putc(':');
			for(count_j=4;count_j<=9;count_j++){
				lcd_putc(gps_time[count_j]);
				}
			lcd_puts(" GMT");
			//num satellites
			lcd_gotoxy(sat_x,sat_y);
			lcd_puts("SAT: ");
			for(count_j=0;sat_numb[count_j]!=',';count_j++){
				lcd_putc(sat_numb[count_j]);
				}
		//2 - LATitude
		lcd_puts("LAT");
		for(count_j=0;count_j<=1;count_j++){ 
			lcd_putc(latitude[count_j]);
			}
		lcd_putc(223);//symbol "�"
		for(count_j=2;count_j<=10;count_j++){ //for(count_j=2;count_j<=9;count_j++){
			lcd_putc(latitude[count_j]);
			}
		lcd_putc(latitude_n_s);
		//3 - LONgitude
		lcd_gotoxy(lon_x,lon_y);
		lcd_puts("LONG: ");
		for(count_j=0;count_j<=1;count_j++){
			lcd_putc(longitude[count_j]);
		}
		lcd_putc(223);//symbol "�"
		for(count_j=2;count_j<=10;count_j++){//for(count_j=2;count_j<=9;count_j++){
			lcd_putc(longitude[count_j]);
		}
		lcd_putc(longitude_w_e);
		_delay_ms(6000);
		//3 - DOP
		lcd_clrscr();
		lcd_puts("DOP: ");
		for(count_j=0;DOP[count_j]!=',';count_j++){
			lcd_putc(DOP[count_j]);
			}
		//ALTitude
		lcd_gotoxy(alt_x,alt_y);
		lcd_puts("ALT");
		for(count_j=0;alt[count_j]!=',';count_j++){
			lcd_putc(alt[count_j]);
			}
		lcd_gotoxy(alt_x+3,alt_y);
		lcd_puts("m");
		_delay_ms(2500);
		
	} // for
	return 0; // never reached
}
} //main




