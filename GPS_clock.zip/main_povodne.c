/*************************************************************************
Title:    Interprets NMEA messages on the UART
Author:   crasbe  <crasbe@gmail.com>  http://www.crasbe.de/
          Peter Fleury (LCD- and UART-Library)
File:     main.c
Software: AVR-GCC 
Hardware: HD44780 compatible LCD text display
		  GPS module sending NMEA messages over serial
		  i2C pins for LCD, 1 for UART
 $GPGGA,123519,4807.038,N,01131.324,E,1,08,0.9,545.4,M,46.9,M, , *42
		1  ,   2   ,2,    3    ,3,    4,5, 6  ,7,      8  ,9,  10
	01 - 123519 = Acquisition du FIX a 12:35:19 UTC
	02 - 4807.038,N = Latitude 48�07.038' N
	03 - 131.324,E = Longitude 11�31.324' E
	04 - 1 = Fix qualification : (0 = non valide, 1 = Fix GPS, 2 = Fix DGPS)
	05 - 08 = Number os satellites en poursuite.
	06 - 0.9 = DOP (Horizontal dilution of position) Dilution horizontale.
	07 - 545.4,M = Altitude, en Metres, au dessus du MSL (mean see level) niveau moyen des Oc�ans.
	08 - 46.9,M = Correction de la hauteur de la g�oide en Metres par rapport a l'�llipsoide WGS84 (MSL).
	09 - (Champ vide) = nombre de secondes �coul�es depuis la derniere mise a jour DGPS.
	10 - (Champ vide) = Identification de la station DGPS.
	11 - *42 = Checksum
	12 - Non repr�sent�s CR et LF.

**************************************************************************/
#include <avr/io.h>
#include <avr/sleep.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>

#include <util/delay.h>
#include "lcdpcf8574/lcdpcf8574.h"	//i2c addr 3F 
//#include "lcd.h"
#include "uart.h"
#include "gpsclock.h"

#define REVISION "R2 2019"


int main(void) {
	unsigned int c; 		// received char from the UART
	unsigned char input;	// the same, converted to char
	
	uint8_t led = 0; //display ON
	uint8_t state = NO_CMD; // state of the receiving process

	
	// comma position
	// GPGGA - time after first comma, satellite count after seventh comma
	//       - $GPGGA,hhmmss.00,,,,,,nn,,
	// GPGSA - lock after second comma
	//		 - $GPGSA,,l,,,,
	uint8_t comma = 0;
	
	// buffer for receiving command, time, satellite count or lock state
	char buffer[9];
	char gps_time[10], latitude[14], longitude[14], sat_numb[5], DOP[5], alt[8];
	uint8_t GPGGA_lock, gps_temp, count_j, count_k, latitude_n_s, longitude_w_e;

	uint8_t bufpos = 0;
	
	// receive the lock state
	uint8_t lock = 1;
	
	//-------init LCD 
	lcd_init(LCD_DISP_ON);
    lcd_home();
	lcd_led(led);

	/*
	// initialize the LED port
	LED_NOLOCK_DDR |= (1 << LED_NOLOCK);	// outputs
	LED_2DLOCK_DDR |= (1 << LED_2DLOCK);
	LED_3DLOCK_DDR |= (1 << LED_3DLOCK);
	LED_NOLOCK_PORT |= (1 << LED_NOLOCK);	// no lock at startup
	LED_2DLOCK_PORT &= ~(1 << LED_2DLOCK);
	LED_3DLOCK_PORT &= ~(1 << LED_3DLOCK);
	*/
	
	
	// initialize UART and enable interrupts
	uart_init( UART_BAUD_SELECT(UART_BAUD_RATE,F_CPU) );
	sei();
	
	//lcd_init(LCD_DISP_ON); 		// initialize display, cursor off
	//lcd_clrscr(); 				// clear the LCD
	
	lcd_puts_P("GPS-Clock, "REVISION);
	
	_delay_ms(2000);
	
	// the ublox-module should be booted now..
#ifdef UBLOX_CONF
	for(uint8_t i = 0; i < 40; i++) {
		uart_putc((unsigned char) pgm_read_byte(&(configuration[i])));
	}
#endif	
	
	lcd_clrscr();
	lcd_puts_P(TXT_TEMPLATE);	// write a template to the screen
	
	for (;;) {
		set_sleep_mode(SLEEP_MODE_IDLE);
        sleep_mode();
		c = uart_getc(); // get a char from the buffer
		
		if (c & UART_NO_DATA) { // nothing received
			continue;
		} else if(	c & UART_FRAME_ERROR || c & UART_OVERRUN_ERROR || 
					c & UART_BUFFER_OVERFLOW) {
			uart_puts_P("UART Error!\n");
			continue;
		}

		input = (unsigned char) c; // convert input to unsigned char
		
		if(input == '\n') { // the party with this line is over
			state = NO_CMD;
			comma = 0;
			lock = 1;
			bufpos = 0;
			continue;
			} else if(input == '$') { // new line, new luck
				state = RECV_CMD;
				continue;
			} else if(input == ',') {
				comma += 1;
				bufpos = 0;
			
			// we finished receiving the command
			if(state == RECV_CMD) 
				{
				// is our command "GPG*A"?
				if(	buffer[0] == 'G' && buffer[1] == 'P' && 
					buffer[2] == 'G' && buffer[4] == 'A') 
					{
					if(buffer[3] == 'G') // GPGGA
						state = RECV_GPGGA;
					else if(buffer[3] == 'S') // GPGSA
						state = RECV_GPGSA;
					else // something else
						state = NO_CMD;
					} else // something else
					state = NO_CMD;
				} else if(	state == RECV_GPGGA && lock == 1 && 
						comma == 2 && buffer[0] != 'G') 
					{ 	// no lock yet
						// on a cold start the module does not even output the
						// RTC time, so there is no time in buffer
					displayTime(buffer);
					#ifdef RTC_TXT
					lcd_gotoxy(RTC_X, RTC_Y);
					lcd_puts_P("RTC");
					#endif 
					}
				continue;
		} 
		
		if(state == RECV_CMD || (state == RECV_GPGGA && (comma == 1 || comma == 7))) { // fill the command buffer
			buffer[bufpos] = input;
			bufpos++;

		} else if(state == RECV_GPGGA) { // time and satellite count
			if(comma == 2) {
				displayTime(buffer);
				#ifdef RTC_TXT
					   lcd_gotoxy(RTC_X, RTC_Y);
					   lcd_puts_P("   ");
				#endif 
			} 
		else if(comma == 8) { // satellite count received
				lcd_gotoxy(SAT_X, SAT_Y);
				lcd_putc(buffer[0]);
				lcd_putc(buffer[1]);
				}

			// ****************  Get alt, lat, lon  ******************
		else if(comma == 10) { // altitude received
				lcd_gotoxy(alt_X, alt_Y);
				lcd_putc(buffer[2]);
				lcd_putc(buffer[3]);
				lcd_putc(buffer[4]);
				lcd_putc(buffer[5]);
				lcd_putc(buffer[6]);
				lcd_putc(buffer[7]);
				lcd_putc(buffer[8]);
				//lcd_puts_P("m");
				}
				/*							latitude[0] = input;
									for(count_j=0;input != ',';count_j++){ //for(count_j=1;gps_temp != ',';count_j++){
										
										if(comma == 2) 
											latitude[count_j] = input;								
									}
									// N/S
									//latitude_n_s = input;
									// Jump ,
															
									// ************  Get longitude  **************
									longitude[0] = input;
									for(count_j=1;input != ',';count_j++){
										longitude[count_j] = input;								
									}
									// W/E
									longitude_w_e = input;
									// jump 1,
									



//-----------------
*/

		} else if(state == RECV_GPGSA) {
			if(comma == 2) { // receive lock state
				lock = (uint8_t) (input-0x30); // better than atoi
				
				lcd_gotoxy(LOCK_X, LOCK_Y);
				if(lock == 1) {
					lcd_puts_P("NO");
					LED_NOLOCK_PORT |= (1 << LED_NOLOCK);
					LED_2DLOCK_PORT &= ~(1 << LED_2DLOCK);
					LED_3DLOCK_PORT &= ~(1 << LED_3DLOCK);
				} else if(lock == 2) {
					lcd_puts_P("2D");
					LED_NOLOCK_PORT &= ~(1 << LED_NOLOCK);
					LED_2DLOCK_PORT |= (1 << LED_2DLOCK);
					LED_3DLOCK_PORT &= ~(1 << LED_3DLOCK);
				} else if(lock == 3) {
					lcd_puts_P("3D");
					LED_NOLOCK_PORT &= ~(1 << LED_NOLOCK);
					LED_2DLOCK_PORT &= ~(1 << LED_2DLOCK);
					LED_3DLOCK_PORT |= (1 << LED_3DLOCK);
				}
			}
		}
	}
	return 0; // never reached
} 
